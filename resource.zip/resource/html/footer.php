<link rel="stylesheet" href="/resource/css/footer.css">
<footer class="footer-distributed">

  <div class="footer-right">

    <!--<a href="#"><i class="fa fa-facebook"></i></a>
    <a href="#"><i class="fa fa-twitter"></i></a>
    <a href="#"><i class="fa fa-linkedin"></i></a>
    <a href="#"><i class="fa fa-github"></i></a>-->

  </div>

  <div class="footer-left">

    <p class="footer-links">
      <a href="/home">Home</a>
      ·
      <a href="https://medium.com/@donaldtracker">Blog</a>
      ·
      <a href="/pages/about">About</a>
      ·
      <a href="/pages/shortcuts/latestArticle">Article</a>
      ·
      <a href="/pages/contact">Contact</a>
    </p>

    <p>DonaldTracker &copy; 2017</p>
  </div>

</footer>
