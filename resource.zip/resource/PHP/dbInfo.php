<?php

$servername = "localhost";
$username = "root";
$password = "root";
$dbPosts = "posts";
$dbRate = "votes";

 ?>
