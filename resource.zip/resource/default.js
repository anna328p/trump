$(document).ready(function(){

console.log("Default JS loaded.");


});
