$(document).ready(function() {
  $('#header').scrollToFixed();
});
