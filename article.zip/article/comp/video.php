<div class = "videoContainer borderPlease">
  <table>
    <tr>
      <td><div class = "videoTitle tableTitle">Videos</div></td>
      <td>
        <div class = "theVideos">
          <table>
            <tr>
              <td><div class = "video"><div class='embed-container'><iframe src='http://www.youtube.com/embed/<?php echo substr($YT1, -11)?>' frameborder='0' allowfullscreen></iframe></div></div></td>
              <td><div class= "video2"><div class='embed-container'><iframe src='http://www.youtube.com/embed/<?php echo substr($YT2, -11)?>' frameborder='0' allowfullscreen></iframe></div></div></td>
            </tr>
          </table>

        </div>
      </td>
      </div></td>
    </tr>
  </table>

</div>
