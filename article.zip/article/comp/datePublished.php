<div class = "datePublishedContainer">
  <div class = "dateText monospace">Published <?php echo $pDate ?> | Week <?php echo $week ?> </div>
</div>
