<div class = "proContainer borderPlease">
  <table>
    <tr>
      <td><div class = "proTitle tableTitle">Pro</div></td>
      <td><div class = "pro monospace"><?php echo $pro?></div></td>
    </tr>
  </table>
</div>
