<div class = "conContainer borderPlease">
  <table>
    <tr>
      <td><div class = "conTitle tableTitle">Con</div></td>
      <td><div class = "con monospace"><?php echo $con?></div></td> 
    </tr>
  </table>
</div>
