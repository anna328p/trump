<div class ="readMoreContainer borderPlease">
  <table>
    <tr>
      <td><div class = "readMoreTitle tableTitle">Read more</div></td>
      <td>
          <table id = "tableIcons">
            <tr>
              <td><a href = "<?php echo $nL1 ?>"><img class = "newsIcon" src = "images/newsIcons/<?php echo $nS1?>.png" /></a></td>
              <td><a href = "<?php echo $nL2 ?>"><img class = "newsIcon" src = "images/newsIcons/<?php echo $nS2?>.png" /></a></td>
              <td><a href = "<?php echo $nL3 ?>"><img class = "newsIcon" src = "images/newsIcons/<?php echo $nS3?>.png" /></a></td>
              <td><a href = "<?php echo $nL4 ?>"><img class = "newsIcon" src = "images/newsIcons/<?php echo $nS4?>.png" /></a></td>
            </tr>
          </table>
      </td>
    </tr>
  </table>
</div>
