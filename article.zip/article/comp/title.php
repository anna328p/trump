<div class='title'>Trump Removes Common Core</div>
<div class='date'>Feburary 17th, 2017</div>
