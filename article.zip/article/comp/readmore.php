<div class='readMore'>
  Read More
</div>
  <div class='links'>
    <ul>
      <li>
        <img class='logo' src='../article/media/cnn.png'>
        <div class="readMoreText">
          Common Core = Common Bore?
        </div>
      </li>
      <li>
        <img class='logo' src="../article/media/foxnews.jpg">
        <div class="readMoreText">
          New Education Reform
        </div>
      </li>
      <li>
        <img class='logo' src="../article/media/twitter.png">
        <div class="readMoreText">
          #CommonNoMore
        </div>
      </li>
    </ul>
  </div>
