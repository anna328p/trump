<div class = "headContainer" style = "background-image: linear-gradient( rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0.5) ), url('<?php echo $image ?>');">
<div class = "headline"><?php echo $name ?></div>
</div>
