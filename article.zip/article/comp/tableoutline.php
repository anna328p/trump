<table>
  <tr>
    <td> <?php include '../article/comp/summary.php' ?> </td>
    <td> <?php include '../article/comp/video.php' ?> </td>
  </tr>
  <tr>
    <td> <?php include '../article/comp/proscons.php' ?> </td>
    <td> <?php include '../article/comp/readmore.php' ?> </td>
  </tr>
</table>
