<div class='prosCons'>
  <div class='pros'>
    Pros
    <ul class='list'>
      <li>• (reason 1)</li>
      <li>• (reason 2)</li>
      <li>• (reason 3)</li>
    </ul>
  </div>
  <div class="cons">
    Cons
    <ul class='list'>
      <li>• (reason 1)</li>
      <li>• (reason 2)</li>
      <li>• (reason 3)</li>
    </ul>
  </div>
</div>
