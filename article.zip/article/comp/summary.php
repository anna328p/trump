<div class = "summaryContainer borderPlease">
  <table>
    <tr>
      <td><div class = "summaryTitle tableTitle">Summary</div></td>
      <td><div class = "summary"><?php echo $summary ?></div></td>
    </tr>
  </table>
</div>
