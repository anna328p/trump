<?php
require '../../../resource/head.php';
require '../../../resource/PHP/getLatest/article.php';
?>

<script>window.location = '/article?w=<?php echo $latestArticleWeek ?>'</script>
