<div class = "section otherTitle what">What we do</div>
<div class = "otherP">Your data is only accounted for when you vote on an article. When you vote for an article, your information at that time is transfered. We use the information you give us to generate some more speicific scores. For example, if you give us your income, we can genreate the score of people that have the same income of you. It allows us to dive in deeper into what different groups of people think of Donald Trump.</div>
<hr>
