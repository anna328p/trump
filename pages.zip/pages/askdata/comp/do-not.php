<div class = "section otherTitle not">What we don't do</div>
<div class = "otherP">Maybe what is most important is what we don't do. We do not sell your data or give your data to anybody else. All your data stays and lives only in DonaldTraker. We also do not use your info to target advertisments towards you. You can be assured that your data is only used to generate better and more accurate scores of Donald Trump.</div>
<hr>
