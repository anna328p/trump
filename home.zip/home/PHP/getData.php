<?php

$rNumber = 2;

require 'PHP/getMainScore.php'; //get main score
require 'PHP/getDemocratScore.php'; //get democrat score
require 'PHP/getRepublicanScore.php'; // get republican score
require 'PHP/getGenderScore.php'; // get a score from a gender
require '../resource/PHP/getLatest/article.php'; //get the latest article information
require 'PHP/getWeekScore.php'; //get the week score
require 'PHP/getLessThanAgeScore.php'; //get less than age score
require 'PHP/getMoreThanAgeScore.php'; //get less than age score

 ?>
