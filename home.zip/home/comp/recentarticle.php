<div class = "articleContainer">
  <table>
    <tr>
      <td><a href="../article?w=<?php echo $latestArticleWeek?>"><div class = "recentEvent monospace"><?php echo $latestArticleName ?></div></a></td>
      <td><div class = "recentEventDate monospace"><?php echo strtok($latestArticleDate, ',')?></div></td>
    </tr>
    <tr>
      <td><div class = "monospace voteAvailable">Voting for this topic is still available.</div></td>
    </tr>
  </table>
</div>
