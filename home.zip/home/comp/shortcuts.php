<div class = "shortcutsContainer">
  <table>
    <tr>
      <td class = "shortcutTD"><a href = "/pages/about"><div class = "shortcut sDataCenter">Learn More</div></a></td>
      <td class = "shortcutTD"><a href = "#"><div class = "shortcut sNewsWall">News Wall</div></a></td>
      <td class = "shortcutTD"><a href = "https://medium.com/@donaldtracker"><div class = "shortcut sBlog">Blog</div></a></td>
    </tr>
  </table>

</div>
