<div class = "subtitle chartSub">
Trump over time...</div>

<div class ="legendContainer">
  <div class = "row">
    <div class = "col s2 theLegend">

      <ul>

        <li>
          <div class ="row">
            <div class = "col s4">
              <div class = 'green legendCircle'>&nbsp</div>
            </div>
            <div class ="col s8">
              <div class="legendSub">Overall</div>
            </div>
          </div>
        </li>

        <li>
          <div class ="row">
            <div class = "col s4">
              <div class = 'red legendCircle'>&nbsp</div>
            </div>
            <div class ="col s8">
              <div class="legendSub">Republican</div>
            </div>
          </div>
        </li>

        <li>
          <div class ="row">
            <div class = "col s4">
              <div class = 'blue legendCircle'>&nbsp</div>
            </div>
            <div class ="col s8">
              <div class="legendSub">Democrat</div>
            </div>
          </div>
        </li>


      </ul>

    </div>

    <div class = "col s10 theMainChart">
      <div id = "thechart"></div>

    </div>

  </div>
</div>
