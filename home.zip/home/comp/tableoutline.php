<div id ="desktopfriendly">
<table id = "outline">

<tr>

<td class="thirds" id ='leftsection'><!--left section-->

<?php require 'left.php' ?>

</td>

<td class="thirds" id ='middlesection'><!--middle section-->

<?php require 'middle.php' ?>

</td><!--end of middle section-->

<td class="thirds" id ='rightsection'><!--right section-->

<?php require 'right.php' ?>

</td><!--end of right section-->


</tr>



</table>
</div>
