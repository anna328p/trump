<table id = 'right'>

<tr id = 'right1'>


<td id = "republicanscore">Republican score</td>

<td>  <!--Circle here-->

<div id = "repScore" class = "circle getScore smaller rScore">
<?php echo $republicanScore ?>
</div>

</td>

</tr>


<tr id = 'right2'>


<td id = "democratscore">Democrat score</td>

<td>

  <div id = "demScore" class = "circle getScore smaller dScore">
  <?php echo $democratScore ?>
  </div>

</td>

</tr>




</table>
