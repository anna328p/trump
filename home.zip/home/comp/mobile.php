<div id ="mobilefriendly">
<br>
<div>
<?php include "middle.php" ?>
</div>

<br><br>

<?php include "right.php" ?>
</div>
