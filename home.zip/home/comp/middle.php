<div id = "mScore" class = "circle getScore larger">
<?php echo $mainScore ?>
</div>
<div id = "mainsub">Current score</div>
