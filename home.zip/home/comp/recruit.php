<div class = "recruitContainer">
  <table>
    <tr>
      <td><div id ="joinUs">We track Donald Trump's public perception over time by taking your opinion. Join us to gather a more accurate score.</div></td>
      <td><a href="../l/login/signup.php" class="action-button shadow animate greenButton">Sign Up</a></td>
    </tr>
  </table>
</div>
