<table id = 'left'>

<tr id = 'left1'>

<td>  <!--Circle here-->

<div class = "circle smaller" id = "lastweek">
0
</div>

</td>
<td id = "lastweekd">Change since last week</td>

</tr>


<tr id = 'left2'>

<td>

  <div class = "circle smaller" id = "lastmonth">
  0
  </div>

</td>
<td id = "lastmonthd">Change since last month</td>

</tr>




</table>
